//
//  ACAppDelegate.h
//  AcuCom
//
//  Created by wfs-aculearn on 14-3-27.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@class Reachability;
@class CTTelephonyNetworkInfo;
@interface ACAppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>
{
    CTTelephonyNetworkInfo      *_networkInfo;
    UIBackgroundTaskIdentifier  _bgTask;
    CLLocationManager           *_locationManager;
}

@property (strong, nonatomic) UIWindow      *window;

+(void)registerForRemoteNotification;
+(void)activeNotification:(NSDictionary*)pCallUserInfo;
+(BOOL)canShowNotification;
@end
