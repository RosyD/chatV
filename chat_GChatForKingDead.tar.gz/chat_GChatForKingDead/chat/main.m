//
//  main.m
//  AcuCom
//
//  Created by wfs-aculearn on 14-3-27.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACAppDelegate.h"


int main(int argc, char * argv[])
{
    @autoreleasepool {
        
//        NSPredicate* Tt = [NSPredicate predicateWithFormat:@"firstname LIKE \'*\'"];
        
        // 将日志文件重定向到ITLog.txt文件中去，方便测试时找bug用
#ifdef ACUtility_Log_UseFile
        [ACUtility LogFile_Swich];
#endif
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACAppDelegate class]));
    }
}
