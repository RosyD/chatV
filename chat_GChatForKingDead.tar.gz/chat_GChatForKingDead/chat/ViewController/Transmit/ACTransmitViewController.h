//
//  ACTransmitViewController.h
//  AcuCom
//
//  Created by 王方帅 on 14-5-20.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACMessage.h"


@interface ACTransmitViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
{
    IBOutlet UITableView        *_mainTableView;
    IBOutlet UILabel            *_titleLabel;
    IBOutlet UIButton           *_createNewChatButton;
    IBOutlet UILabel            *_nearestLabel;
    IBOutlet UIButton           *_gobackButton;
    IBOutlet UIView             *_tableHeaderView;
}

@property (nonatomic,strong) NSMutableArray     *dataSourceArray;
@property (nonatomic,strong) NSArray            *messages;
@property (nonatomic) ACTopicEntity             *selectTopicEntity;
@property (nonatomic) BOOL                      isOpenHotspot;
@property (nonatomic) BOOL                      isHadTransmit;
@property (nonatomic) BOOL                      isForVideoCall; //当messages为空时，是否是VideoCall或AudioCall
@property (nonatomic,weak) UIViewController*    superVCForVideoCall;

@end
