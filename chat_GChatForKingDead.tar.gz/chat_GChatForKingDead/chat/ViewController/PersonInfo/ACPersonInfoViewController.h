//
//  ACPersonInfoViewController.h
//  AcuCom
//
//  Created by 王方帅 on 14-5-4.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCPlaceholderTextView.h"
#import "ACChangeIconVC_Base.h"

extern NSString *const kPersonInfoPutSuccessNotifation;

@interface ACPersonInfoViewController : ACChangeIconVC_Base<UITextFieldDelegate,UITextViewDelegate>
{
    IBOutlet UIView         *_contentView;
    
    IBOutlet UIButton       *_backButton;
    IBOutlet UILabel        *_titleLabel;
    IBOutlet UIButton       *_saveButton;
    
    float                   _descHeight;
}


@property (nonatomic) BOOL              isOpenHotspot;

@end
