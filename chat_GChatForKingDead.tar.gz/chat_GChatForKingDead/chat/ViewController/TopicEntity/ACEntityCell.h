//
//  ACEntityCell.h
//  AcuCom
//
//  Created by wfs-aculearn on 14-4-2.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACEntity.h"
//#import "AttributedLabel.h"

#define ACEntityCell_Hight  70  

@class ACChatViewController;
@interface ACEntityCell : UITableViewCell<UIActionSheetDelegate,UIAlertViewDelegate>
{
    IBOutlet UIImageView    *_iconImageView;
    IBOutlet UILabel        *_nameLabel;
    UILabel         *_searchNameLabel;
    IBOutlet UILabel        *_contentLabel;
    IBOutlet UIImageView    *_locationImageView;
    IBOutlet UIImageView    *_destructImageView;
    IBOutlet UIImageView    *_muteFlagImageView;

    IBOutlet UILabel        *_timeLabel;
    IBOutlet UIButton       *_unReadNumButton;
    ACChatViewController    *_superVC;
    ACTopicEntity           *_topicEntity;
    ACUrlEntity             *_urlEntity;
    ACBaseEntity            *_entity;
    
    IBOutlet UILabel        *_urlEntityTypeLabel;
    
    int                     _nLongPressFuncType;
}

-(void)setEntity:(ACBaseEntity *)entity superVC:(ACChatViewController *)superVC;
-(void)setEntityForTransmit:(ACBaseEntity *)entity; //被 ACTransmitViewController 使用
+(instancetype)cellForTableView:(UITableView*)tableView;

@end
