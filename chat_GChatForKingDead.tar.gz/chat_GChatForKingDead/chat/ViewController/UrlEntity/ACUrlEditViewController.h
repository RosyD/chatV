//
//  ACUrlEditViewController.h
//  chat
//
//  Created by Aculearn on 15/4/23.
//  Copyright (c) 2015年 Aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACEntity.h"

@interface ACUrlEditViewController : UIViewController

@property (nonatomic,strong) ACUrlEntity          *urlEntity;

@end
