//
//  ACRepeatDayCell.m
//  chat
//
//  Created by 王方帅 on 14-8-5.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import "ACRepeatDayCell.h"

@implementation ACRepeatDayCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setIndex:(int)index
{
    NSString *title = nil;
    switch (index)
    {
        case RepeatDay_Sunday:
        {
            title = @"Sunday";
        }
            break;
        case RepeatDay_Monday:
        {
            title = @"Monday";
        }
            break;
        case RepeatDay_Tuesday:
        {
            title = @"Tuesday";
        }
            break;
        case RepeatDay_Wednesday:
        {
            title = @"Wednesday";
        }
            break;
        case RepeatDay_Thursday:
        {
            title = @"Thursday";
        }
            break;
        case RepeatDay_Friday:
        {
            title = @"Friday";
        }
            break;
        case RepeatDay_Saturday:
        {
            title = @"Saturday";
        }
            break;
        default:
            break;
    }
    [_titleLabel setText:title];
}

-(void)setSelect:(BOOL)select
{
    [_selectedButton setSelected:select];
}

@end
