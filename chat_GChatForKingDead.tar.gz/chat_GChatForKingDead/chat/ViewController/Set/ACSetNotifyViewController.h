//
//  ACSetViewController.h
//  AcuCom
//
//  Created by wfs-aculearn on 14-3-28.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>


@interface ACSetNotifyViewController : UIViewController //<UIAlertViewDelegate>

@property (nonatomic) BOOL                      isOpenHotspot;

@end
