//
//  ACLocationSettingViewController.h
//  chat
//
//  Created by 王方帅 on 14-6-17.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CXAlertView.h"

#define kLocationStartTime      @"locationStartTime"
#define kLocationStopTime       @"locationStopTime"
#define kLocationAllDayClose     @"locationAllDayClose"

enum locationState
{
    locationState_None,
    locationState_StartTime,
    locationState_StopTime,
};

@interface ACLocationSettingViewController : UIViewController
{
//    UIDatePicker        *_datePicker;
    enum locationState  _locationState;
    
    IBOutlet UILabel    *_startTimeLabel;
    IBOutlet UILabel    *_stopTimeLabel;
    IBOutlet UISwitch   *_alldaySwitch;
    
    IBOutlet UIView     *_startTimeView;
    IBOutlet UIView     *_stopTimeView;
    
    IBOutlet UILabel    *_promptLabel;
    IBOutlet UIView     *_alldayView;
    IBOutlet UIView     *_alldayLineView;
    
    IBOutlet UILabel    *_beginTimeLabel;
    IBOutlet UILabel    *_endTimeLabel;
    
    IBOutlet UILabel    *_weekLabel;
}

@property (nonatomic) BOOL                      isOpenHotspot;

-(void)setWeekTitle:(NSString *)weekTitle;

@end
