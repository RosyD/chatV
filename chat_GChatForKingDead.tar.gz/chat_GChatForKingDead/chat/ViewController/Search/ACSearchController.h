//
//  ACSearchController.h
//  chat
//
//  Created by 王方帅 on 14-7-8.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kTopicTotal     @"topicTotal"
#define kUserGroupTotal @"userGroupTotal"
#define kUserTotal      @"userTotal"
#define kAccountTotal   @"accountTotal"

enum SearchCountType
{
    SearchCountType_Topic,
    SearchCountType_User,
    SearchCountType_UserGroup,
    SearchCountType_AccountUser,
};

enum SearchMode
{
    SearchMode_Search,
    SearchMode_History,
};

@class ACChatViewController;
@interface ACSearchController : UIViewController<UISearchBarDelegate,UIAlertViewDelegate>
{
    IBOutlet UITableView    *_mainTableView;
    IBOutlet UISearchBar    *_searchBar;
    IBOutlet UIView         *_contentView;
    IBOutlet UISwitch       *_privacyModeSwitch;
//    __weak IBOutlet UIButton *_privacyModeButton;
    
    IBOutlet UIView         *_tableFooterView;
    IBOutlet UIButton       *_clearHistoryButton;
}

@property (nonatomic,strong) NSString       *searchKey;
@property (nonatomic,strong) NSDictionary   *searchCountDic;
@property (nonatomic,strong) NSMutableArray *dataSourceArray;
@property (nonatomic,strong) NSMutableArray *searchArray;
@property (nonatomic) ACChatViewController  *chatVC;
@property (nonatomic,strong) NSMutableArray *historyList;
@property (nonatomic) enum SearchMode       searchMode;

@end
