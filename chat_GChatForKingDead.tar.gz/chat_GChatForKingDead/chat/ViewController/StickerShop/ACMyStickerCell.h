//
//  ACMyStickerCell.h
//  chat
//
//  Created by 王方帅 on 14-8-20.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACSuit.h"
#import "MCProgressBarView.h"

@class ACMyStickerController;
@interface ACMyStickerCell : UITableViewCell
{
    ACMyStickerController           *_superVC;
    IBOutlet UIImageView            *_iconImageView;
    IBOutlet UILabel                *_titleLabel;
    IBOutlet UIButton               *_downloadButton;
    BOOL                            _isDelete;
    MCProgressBarView               *_progressView;
}

@property (nonatomic,strong) ACSuit     *suit;

-(void)setSuit:(ACSuit *)suit superVC:(ACMyStickerController *)superVC;

-(void)isEditing:(BOOL)isEditing;

-(void)progressUpdate:(float)progress;

@end
