//
//  ACStickerGalleryController.h
//  chat
//
//  Created by 王方帅 on 14-8-14.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACSuit.h"

@class ACChatMessageViewController;
@interface ACStickerGalleryController : UIViewController
{
    IBOutlet UITableView    *_mainTableView;
    IBOutlet UITableView    *_categoryTableView;
    ACChatMessageViewController     *_superVC;
    IBOutlet UIView         *_contentView;
    int                     _requestReturnCount;
}

@property (nonatomic,strong) NSMutableArray     *dataSourceArray;
@property (nonatomic,strong) NSMutableArray     *categoryArray;
@property (nonatomic) int   selectedCategoryIndex;
@property (nonatomic,strong) NSMutableDictionary    *suitCategoryDic;

-(void)downloadSuitWithSuit:(ACSuit *)suit;

- (id)initWithSuperVC:(ACChatMessageViewController *)superVC;

@end
