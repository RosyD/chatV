//
//  ACMyStickerController.h
//  chat
//
//  Created by 王方帅 on 14-8-20.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACSuit.h"

@interface ACMyStickerController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView    *_mainTableView;
    IBOutlet UIView         *_tableHeaderView;
    IBOutlet UIView         *_contentView;
}

@property (nonatomic,strong) NSMutableArray     *downloadArray;
@property (nonatomic,strong) NSMutableArray     *undownloadArray;

-(void)reloadData;

-(void)downloadSuitWithSuit:(ACSuit *)suit;

-(void)removeSuit:(ACSuit *)suit;

+(NSMutableArray*)loadMySuits;  //ACSuit*

@end
