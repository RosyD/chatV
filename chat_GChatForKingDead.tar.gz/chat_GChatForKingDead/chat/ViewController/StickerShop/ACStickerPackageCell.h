//
//  ACStickerPackageCell.h
//  chat
//
//  Created by 王方帅 on 14-8-14.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACSuit.h"
#import "MCProgressBarView.h"

@class ACStickerGalleryController;
@interface ACStickerPackageCell : UITableViewCell
{
    ACStickerGalleryController      *_superVC;
    IBOutlet UIImageView            *_iconImageView;
    IBOutlet UILabel                *_titleLabel;
    IBOutlet UILabel                *_descLabel;
    IBOutlet UIButton               *_downloadButton;
    MCProgressBarView               *_progressView;
}

@property (nonatomic,strong) ACSuit     *suit;

-(void)setSuit:(ACSuit *)suit superVC:(ACStickerGalleryController *)superVC;

-(void)progressUpdate:(float)progress;

@end
