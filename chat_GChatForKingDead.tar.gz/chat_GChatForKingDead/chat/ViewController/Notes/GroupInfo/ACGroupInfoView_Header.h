//
//  ACGroupInfoView_Header.h
//  chat
//
//  Created by Aculearn on 1/21/15.
//  Copyright (c) 2015 Aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACGroupInfoView_Header : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UILabel *memberCountLable;
@property (weak, nonatomic) IBOutlet UIButton *groupEditButton;

@end
