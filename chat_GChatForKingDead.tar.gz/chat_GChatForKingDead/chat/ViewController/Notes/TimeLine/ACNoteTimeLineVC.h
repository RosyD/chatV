//
//  ACNoteTimeLineVC.h
//  chat
//
//  Created by Aculearn on 14/12/30.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import "ACNoteListVC_Base.h"

@interface ACNoteTimeLineVC : ACNoteListVC_Base

//@property (weak, nonatomic) IBOutlet UITableView *mainTableView;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (strong, nonatomic) NSString* noteIdForNotification;

@end