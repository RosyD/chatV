//
//  ACNoteDetailVC.h
//  chat
//
//  Created by Aculearn on 14/12/24.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACNoteMessage.h"
#import "THChatInput.h"
#import "ACTableViewVC_Base.h"

@class ACNoteListVC_Base;
@class ACNoteCommentCell;
@interface ACNoteDetailVC : ACTableViewVC_Base <THChatInputDelegate,UIAlertViewDelegate>


//@property (weak,nonatomic)  IBOutlet UITableView    *mainTableView;
@property (nonatomic,strong) NSObject           *objForCheck; //NSString* noteId fromNotification 或者 ACNoteObject
@property (nonatomic,strong) NSIndexPath        *noteIndexPath;
@property (nonatomic,strong) ACNoteMessage      *noteMessage;
//@property (nonatomic) BOOL                      isOpenHotspot;
@property (nonatomic,weak) ACNoteListVC_Base*   superVC;

-(void)noteContentUpdated;

-(void)refreshForCommentChange;

-(void)selectedCommentCell:(ACNoteCommentCell*)commentCell
          forLongPress:(BOOL)forLongPress; //选择
-(void)moreReplies:(ACNoteComment*)comment;



@end
