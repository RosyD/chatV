//
//  ACNoteUpdateVC.m
//  chat
//
//  Created by Aculearn on 14/12/29.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import "ACNoteUpdateVC.h"
#import "UINavigationController+Additions.h"

@interface ACNoteUpdateVC ()

@property (weak, nonatomic) IBOutlet UITextView *textViewForNote;

@end

@implementation ACNoteUpdateVC


- (void)viewDidLoad {
    [super viewDidLoad];
    _textViewForNote.text   =   _superVC.noteMessage.content;

    [_textViewForNote becomeFirstResponder];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//-(void)viewDidAppear:(BOOL)animated{
//    [super viewDidAppear:animated];
//    }

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)updateNote:(id)sender {
    if(![_superVC.noteMessage.content isEqualToString:_textViewForNote.text]){
        _superVC.noteMessage.content = _textViewForNote.text;
        [_superVC noteContentUpdated];
    }
    [self.navigationController ACpopViewControllerAnimated:YES];
}

- (IBAction)goback:(id)sender {
    [self.navigationController ACpopViewControllerAnimated:YES];
}

@end
