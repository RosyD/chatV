//
//  ACNoteUpdateVC.h
//  chat
//
//  Created by Aculearn on 14/12/29.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACNoteDetailVC.h"

@interface ACNoteUpdateVC : UIViewController

@property (nonatomic,weak) ACNoteDetailVC* superVC;
@end
