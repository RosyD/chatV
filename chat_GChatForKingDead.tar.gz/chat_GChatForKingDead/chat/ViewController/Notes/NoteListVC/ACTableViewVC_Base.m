//
//  ACTableViewVC_Base.m
//  chat
//
//  Created by Aculearn on 14/12/25.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import "ACTableViewVC_Base.h"
#import "MJRefresh.h"

@interface ACTableViewVC_Base (){
    UIView                     *_tableHeaderView;
    UIActivityIndicatorView    *_activityView;
}

@end

@implementation ACTableViewVC_Base

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mainTableView.delegate =   self;
    self.mainTableView.dataSource = self;
    
    _nRefreshType   =   ACTableViewVC_Base_RefreshType_Init;

    if(!_bNotNeedRefreshHead){
        //添加上面的刷新
        [self.mainTableView addHeaderWithCallback:^{
            _nRefreshType   =   ACTableViewVC_Base_RefreshType_Head;
            [self LoadDataFunc];
        }];
    }
    
    //下面的刷新
    [self.mainTableView addFooterWithCallback:^{
        _nRefreshType   =   ACTableViewVC_Base_RefreshType_Tail;
        [self LoadDataFunc];
    }];
    
    
    NSInteger nWidth =  self.view.frame.size.width;
    _tableHeaderView    =   [[UIView alloc] initWithFrame:CGRectMake(0, 0,nWidth, 20)];
    _activityView       =   [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake((nWidth-20)/2, 0,20, 20)];
    _activityView.activityIndicatorViewStyle  =UIActivityIndicatorViewStyleGray;
    [_tableHeaderView addSubview:_activityView];
    self.mainTableView.tableHeaderView = _tableHeaderView;
    [_activityView startAnimating];
    
    _nRefreshType   =   ACTableViewVC_Base_RefreshType_Init;

    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hotspotStateChange:) name:kHotspotOpenStateChangeNotification object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)scrollToIndex:(NSInteger)nIndex animated:(BOOL)animated{
    [self.mainTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:nIndex inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:animated];
}

-(void)refreshFocus{
    _nRefreshType   =   ACTableViewVC_Base_RefreshType_Focus;
    [self.view showProgressHUD];
    [self LoadDataFunc];
}

-(void)LoadDataFuncEnd_WithCount:(NSInteger)nLoadCount{
    
    [self.view hideProgressHUDWithAnimated:NO];
    
    ACTableViewVC_Base_RefreshType nRefreshType =   _nRefreshType;
    _nRefreshType   =   ACTableViewVC_Base_RefreshType_Nouse;
    
    if(ACTableViewVC_Base_RefreshType_Init==nRefreshType){
        //初始化
        [_activityView stopAnimating];
        _activityView       =   nil;
        _tableHeaderView    =   nil;
        self.mainTableView.tableHeaderView = nil;
        [self.mainTableView reloadData];
        return;
    }
    
    //停止动画

    if(ACTableViewVC_Base_RefreshType_Head==nRefreshType){
        [self.mainTableView headerEndRefreshing];
    }
    else if(ACTableViewVC_Base_RefreshType_Tail==nRefreshType){
        [self.mainTableView footerEndRefreshing];
    }
    
    [self.mainTableView reloadData];
    if(ACTableViewVC_Base_RefreshType_Head==_nRefreshType){
        [self scrollToIndex:0 animated:YES];
    }
    
    /*
    if(ACTableViewVC_Base_RefreshType_Head==_nRefreshType){
        [self.mainTableView reloadData];
        [self scrollToIndex:0 animated:YES];
    }
    else if(nLoadCount){
        //刷新数据
        [self.mainTableView reloadData];
    }*/
}


@end
