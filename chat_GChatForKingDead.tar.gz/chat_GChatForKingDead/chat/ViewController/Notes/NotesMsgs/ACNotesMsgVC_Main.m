//
//  ACNotesMsgViewController.m
//  chat
//
//  Created by 王方帅 on 14-6-3.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import "ACNotesMsgVC_Main.h"
#import "ACNotesMsgVC_Posts.h"
#import "ACChatMessageViewController.h"
#import "UINavigationController+Additions.h"
#import "ACMessageDB.h"
#import "ACNetCenter.h"
#import "ACContributeViewController.h"
#import "ACDataCenter.h"
#import "HMSegmentedControl.h"
#import "ACGroupInfoVC.h"
#import "ACGroupInfoOptionVC.h"


@interface ACNotesMsgVC_Main (){
    CGRect _TheSubViewFrame;
}
@property (weak, nonatomic) IBOutlet UIView *segmentBkView;
@property (weak, nonatomic) IBOutlet UIView *segmenToolsBkView;

@end

@implementation ACNotesMsgVC_Main


//- (id)initWithSuperVC:(ACChatMessageViewController *)superVC
//{
//    self = [super init];
//    if (self) {
//        _superVC = superVC;
//    }
//    return self;
//}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (![ACConfigs isPhone5]){
        [self.view setFrame_height:self.view.size.height-88];
    }
    
    _gotoChatButton.hidden = _isFromChatMessageVC;
    
//    [_segmentForSubViews addTarget:self action:@selector(segmentedControlSelected:) forControlEvents:UIControlEventValueChanged];
//    
//    [_segmentForSubViews setTitle:@"Posts" forSegmentAtIndex:0];
//    [_segmentForSubViews setTitle:@"Members" forSegmentAtIndex:1];
//    _segmentForSubViews.hidden = YES;
    
    
    HMSegmentedControl *segmentedControl = [[HMSegmentedControl alloc] initWithSectionTitles:@[@"Posts", @"Members"]];
    [segmentedControl setFrame:_segmentBkView.bounds];
    segmentedControl.SelectionIndicatorMode =  HMSelectionIndicatorFillsSegment;
    segmentedControl.selectionIndicatorHeight  =2;
//    segmentedControl.alpha = 0.6;
//    segmentedControl.backgroundColor = [UIColor clearColor];
    
    [segmentedControl setIndexChangeBlock:^(NSUInteger index) {
        
        _selectedViewControllerIndex = index;
        _selectedViewController = self.childViewControllers[_selectedViewControllerIndex];
        [self.view addSubview:_selectedViewController.view];
        _selectedViewController.view.frame = _TheSubViewFrame;
        [_selectedViewController didMoveToParentViewController:self];

    }];
    
    [_segmentBkView addSubview:segmentedControl];

    
    
//    NSLog(@"%@",_segmentForSubViews.tintColor);
//    _segmentForSubViews.tintColor = [UIColor colorWithRed:0x77/255. green:0xaa/255 blue:0xbf/255.0 alpha:1];
    //0.356863 0.603922 0.698039
    {
        ACNotesMsgVC_Posts* pPostsVC =  [[ACNotesMsgVC_Posts alloc] init];
        pPostsVC.topicEntity = _topicEntity;
//    pPostsVC.view.frame =   _subView.frame;
        [self addChildViewController:pPostsVC];
        
        
        _titleLable.text    =   _topicEntity.showTitle;
    }

#if 1 //TARGET_IPHONE_SIMULATOR
    {
        ACGroupInfoVC* pGroupInfo = [[ACGroupInfoVC alloc] init];
        pGroupInfo.entity = _topicEntity;
        pGroupInfo.superVC  =   self;
        [self addChildViewController:pGroupInfo];
    }
    
#else
    {
        ACGroupInfoViewController* pGroupInfo = [[ACGroupInfoViewController alloc] init];
        pGroupInfo.topicEntity = _topicEntity;
        pGroupInfo.superVC  =   self;
        [self addChildViewController:pGroupInfo];
    }
#endif
    
    
    _TheSubViewFrame    =   self.view.frame;
    _TheSubViewFrame.origin.y   =   _segmenToolsBkView.frame.origin.y+_segmenToolsBkView.frame.size.height;
    _TheSubViewFrame.size.height    -=  _TheSubViewFrame.origin.y;
    
    
    [segmentedControl setSelectedIndex:0 animated:NO];
    
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(topicInfoChange) name:kDataCenterTopicInfoChangedNotifation object:nil];

    
//    _TheSubViewFrame = _subView.frame;
    
//    [self segmentedControlSelected:nil];
    
    /*
     ACGroupInfoViewController *groupInfoVC = [[ACGroupInfoViewController alloc] initWithSuperVC:self];
     groupInfoVC.singleChatCurrentUserID = self.topicEntity.singleChatUserID;
     [self.navigationController pushViewController:groupInfoVC animated:YES];*/
    
//    [_segmentForSubViews insertSegmentWithTitle:@"Posts" atIndex:_segmentForSubViews.numberOfSegments animated:NO];
//    [_segmentForSubViews insertSegmentWithTitle:@"Members" atIndex:_segmentForSubViews.numberOfSegments animated:NO];
}

- (void)topicInfoChange{
    _titleLable.text  = _topicEntity.title;
}


//
//
//- (void)segmentedControlSelected:(id)sender
//{
//    _selectedViewControllerIndex = _segmentForSubViews.selectedSegmentIndex;
//    _selectedViewController = self.childViewControllers[_selectedViewControllerIndex];
//    [self.view addSubview:_selectedViewController.view];
//    _selectedViewController.view.frame = _TheSubViewFrame;
//    [_selectedViewController didMoveToParentViewController:self];
//}

- (IBAction)gotoChatMessage:(id)sender {
    ACChatMessageViewController *chatMessageVC = [[ACChatMessageViewController alloc] initWithSuperVC:self withTopicEntity:_topicEntity];
//    chatMessageVC.topicEntity = _topicEntity;
//    [chatMessageVC preloadDB];
    [self.navigationController pushViewController:chatMessageVC animated:YES];}

-(IBAction)goback:(id)sender
{
    [self.navigationController ACpopViewControllerAnimated:YES];
}

- (IBAction)onGroupInfoOption:(id)sender {
    ACGroupInfoOptionVC* pGroupInfoOptionVC =  [[ACGroupInfoOptionVC alloc] init];
    pGroupInfoOptionVC.entity  =   _topicEntity;
    pGroupInfoOptionVC.isPushedViewController = YES;
    
//    UINavigationController *navC = [[UINavigationController alloc] initWithRootViewController:pGroupInfoOptionVC];
//    navC.navigationBarHidden = YES;
//    [self ACpresentViewController:navC animated:YES completion:nil];
    
    [self.navigationController pushViewController:pGroupInfoOptionVC animated:YES];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
