//
//  ACNotesMsgViewController.h
//  chat
//
//  Created by 王方帅 on 14-6-3.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACNoteListVC_Base.h"


//@class ACNotesMsgCell;
@interface ACNotesMsgVC_Posts : ACNoteListVC_Base


@property (weak, nonatomic) IBOutlet UIButton *postButton;
@property (weak, nonatomic) IBOutlet UITableView *mainTableView;


@end
