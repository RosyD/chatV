//
//  ACContributeViewController.h
//  chat
//
//  Created by 王方帅 on 14-6-3.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCPlaceholderTextView.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "ACNoteMessage.h"
#import "ACEntity.h"
#import "ELCImagePickerHeader.h"
#import "NIDropDown.h"

enum ACButtonType
{
    ACButtonType_none,
    ACButtonType_photo,
    ACButtonType_video,
    ACButtonType_webLink,
};

#define kHasPhoto   @"hasPhoto"
#define kHasVideo   @"hasVideo"
#define kHasLocation   @"hasLocation"

@class ACNoteListVC_Base;
@interface ACContributeViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,NIDropDownDelegate,UIActionSheetDelegate,UIAlertViewDelegate>
{
    IBOutlet GCPlaceholderTextView      *_textView;
    
    __weak IBOutlet UILabel             *_wallBoardLable; //标题
    IBOutlet UIView                     *_buttonBarView;
    IBOutlet UIImageView                *_buttonBarBgImageView;
    
    IBOutlet UIView                     *_detailView;
    IBOutlet UIImageView                *_detailBgImageView;
    
    IBOutlet UIButton                   *_cameraButton;
    IBOutlet UIButton                   *_photoButton;
    
    IBOutlet UIImageView                *_directImageView;
    IBOutlet UIButton                   *_photoBarButton;
    IBOutlet UIButton                   *_videoBarButton;
    IBOutlet UIButton                   *_locationBarButton;
    

    IBOutlet UIImageView                *_detailHolderImageView;
    
    IBOutlet UITableView                *_detailTableView;
    
    int                                 _movieToMp4FinishedCount;
    
    BOOL                                _isAppear;
    float                               _currentHeight;
    
    //上传进度展示
    IBOutlet UIView                     *_uploadView;
    IBOutlet UIProgressView             *_uploadProgressView;
    IBOutlet UILabel                    *_uploadProgressLabel;
    IBOutlet UILabel                    *_uploadLabel;
    
    IBOutlet UIView                     *_contentView;
    int                                 _movieCount;
    
    IBOutlet UIView                     *_categoryView;
    IBOutlet UIView                     *_promptView;
    
    __weak IBOutlet UILabel *_categoryTitle;
    IBOutlet UIButton                   *_cancelUploadButton;
    IBOutlet UIButton                   *_enterButton;
    IBOutlet UIButton                   *_cancelButton;
    
    int                                 _compresseFailCount;
    IBOutlet UIButton                   *_dropDownButton;
    BOOL                                _isCancelSend;
    
    
    
    __weak IBOutlet UIButton            *_webLinkBarButton;
    __weak IBOutlet UIButton            *_webLinkButton;
    __weak IBOutlet UIButton            *_webLinkDelButton;
    __weak IBOutlet UIView              *_webInfoBk;
    __weak IBOutlet UIImageView         *_webInfoIcon;
    __weak IBOutlet UILabel             *_webInfoTitle;
    __weak IBOutlet UILabel             *_webInfoURL;
    __weak IBOutlet UILabel *_webInfoDesc;
}

@property (nonatomic) enum ACButtonType     buttonType;
//@property (nonatomic,strong) ACWallBoard_Message  *noteMessage;
//@property (nonatomic,strong) ACTopicEntity      *topicEntity;
//@property (nonatomic,strong) NSMutableArray     *detailDataSourceArray;

//@property (nonatomic) CLLocationCoordinate2D    coordinate;
//@property (nonatomic,strong) NSString           *locationAddress;
@property (nonatomic,strong) NSMutableDictionary    *barDic;
@property (nonatomic,strong) NIDropDown         *dropDown;
//@property (nonatomic,strong) ACCategory         *category;
@property (nonatomic) BOOL                      isOpenHotspot;
@property (nonatomic,weak) ACNoteListVC_Base* superVC;

-(instancetype)initForWallBoard:(BOOL)bForWallBoard withSuperVC:(ACNoteListVC_Base*)superVC;

-(void)reloadBarButtonImage;

-(void)removeContent:(ACNoteContentImageOrVideo*)pFile;

-(void)setLocaltion:(ACNoteContentLocation*)localInfo;

//-(void)setLocationCoordinate:(CLLocationCoordinate2D) coordinate withAddress:(NSString*)locationAddress;



@end
