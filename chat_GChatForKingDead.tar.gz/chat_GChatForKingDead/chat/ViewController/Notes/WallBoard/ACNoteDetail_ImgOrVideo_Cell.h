//
//  ACNoteDetail_ImgOrVideo_Cell.h
//  chat
//
//  Created by 王方帅 on 14-6-3.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import <UIKit/UIKit.h>

//enum ACWallBoardType
//{
//    ACWallBoardType_Sticker,
//    ACWallBoardType_Photo,
//    ACWallBoardType_Video,
//};

@class ACNoteMessage;
@class ACNoteContentImageOrVideo;
@class ACNoteListVC_Base;
@interface ACNoteDetail_ImgOrVideo_Cell : UITableViewCell
{
    IBOutlet UIImageView        *_contentImageView;
    IBOutlet UIImageView        *_playImageView;
    int                         _index;
    __weak ACNoteMessage               *_noteMessage;
    __weak ACNoteContentImageOrVideo   *_page;
    __weak ACNoteListVC_Base           *_superVC;
}

-(void)setPage:(ACNoteMessage *)noteMessage index:(int)index withSuperVC:(ACNoteListVC_Base*)superVC;

@end
