//
//  ACNoteDetail_ImgOrVideo_Cell.m
//  chat
//
//  Created by 王方帅 on 14-6-3.
//  Copyright (c) 2014年 王方帅. All rights reserved.
//

#import "ACNoteDetail_ImgOrVideo_Cell.h"
#import "ACNoteMessage.h"
#import "ACAddress.h"
#import "UIImage+Additions.h"
#import "UIView+Additions.h"
#import "ACNoteListVC_Base.h"

@implementation ACNoteDetail_ImgOrVideo_Cell

- (void)awakeFromNib
{
    // Initialization code
}

-(void)imageTap:(UITapGestureRecognizer *)tap{
    [_superVC imageOrVideoTapWithNoteMessage:_noteMessage forIndex:_index];
}

-(void)setPage:(ACNoteMessage *)noteMessage index:(int)index  withSuperVC:(ACNoteListVC_Base*)superVC{
    _index = index;
    _noteMessage =  noteMessage;
    _superVC    =   superVC;
    
    ACNoteContentImageOrVideo* page =   noteMessage.imgs_Videos_List[index];
    
    if (_page != page)
    {
        _page = page;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTap:)];
        [_contentImageView addGestureRecognizer:tap];
        
        NSString *imagePath = page.bIsImage?(page.resourceFilePath):(page.thumbFilePath);
        [_playImageView setHidden:page.bIsImage];
        if (imagePath)
        {
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
                float width = image.size.width,height = image.size.height;
                if (width > 640)
                {
                    height /= (width / 640);
                    width = 640;
                }
                image = [image imageScaledToSize:CGSizeMake(width, height)];
                dispatch_async(dispatch_get_main_queue(), ^{
                    _contentImageView.alpha = 0;
                    [UIView beginAnimations:nil context:nil];
                    [UIView setAnimationDuration:0.3];
                    _contentImageView.alpha = 1;
                    _contentImageView.image = image;
                    [UIView commitAnimations];
                    if (page.bIsImage)
                    {
                        _contentImageView.size = CGSizeMake(width/2-10, height/2);
                    }
                    else
                    {
                        _contentImageView.size = CGSizeMake(width, height);
                    }
                    [_contentImageView setFrame_x:5];
                    
                    _playImageView.center = CGPointMake(_contentImageView.size.width/2, _contentImageView.size.height/2);
//                    self.size = CGSizeMake(320, [_contentImageView getFrame_Bottom]+10);
                });
            });
        }
    }
}

@end
