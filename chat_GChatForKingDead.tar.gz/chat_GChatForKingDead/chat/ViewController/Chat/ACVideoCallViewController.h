//
//  ACVideoCallViewController.h
//  chat
//
//  Created by Aculearn on 15/1/29.
//  Copyright (c) 2015年 Aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACUser.h"

@interface ACVideoCallViewController : UIViewController

@property   (nonatomic,strong)  ACUser*   caller;


-(void)cancelWithBlock:(void (^)(void))completion; //强行放弃

@end
