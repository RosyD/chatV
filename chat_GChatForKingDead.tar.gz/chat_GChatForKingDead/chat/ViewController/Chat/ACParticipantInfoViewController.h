//
//  ACParticipantInfoViewController.h
//  AcuCom
//
//  Created by 王方帅 on 14-4-22.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ACUser.h"
#import "ACEntity.h"


#define User_MoreProfile_Y_Delta     8   //间隔
#define User_MoreProfile_Name_X      10
#define User_MoreProfile_Name_Width  70
#define User_MoreProfile_Item_X      (User_MoreProfile_Name_X+User_MoreProfile_Name_Width+5)

@interface ACParticipantInfoViewController : UIViewController
{
    IBOutlet UIScrollView       *_contentView;

    //Icon Name
    IBOutlet UIView             *_iconNameView;
    IBOutlet UIButton           *_iconNameButton;
    IBOutlet UIImageView        *_iconImageView;
    IBOutlet UILabel            *_nameLabel;
    IBOutlet UILabel            *_accountLabel;
    __weak IBOutlet UIImageView *_moreProfileImageView;
    



    IBOutlet UIButton           *_backButton;
    IBOutlet UIButton           *_sendMessageButton;

}

@property (nonatomic,strong) ACUser         *user;
@property (nonatomic,strong) ACTopicEntity  *topicEntity;
@property (nonatomic) BOOL                  isOpenHotspot;

- (instancetype)initWithUserID:(NSString *)userID;
- (instancetype)initWithUser:(ACUser *)user;

//取得用户信息的标题
+(NSString*)userProfileTitleWithItem:(NSString*)pItemName;
+(void)loadUser:(NSString*)pUsrID ProfileFromView:(UIViewController*)pVC withBlock:(void (^)(NSDictionary* pUserProInfo)) pFunc;
//加载用户信息 pFunc(nil)表示失败


@end
