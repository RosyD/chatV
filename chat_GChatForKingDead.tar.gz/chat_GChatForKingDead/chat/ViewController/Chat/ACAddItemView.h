//
//  ACAddItemView.h
//  AcuCom
//
//  Created by 王方帅 on 14-4-14.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACAddItemView : UIView

@property (nonatomic,strong) IBOutlet UIButton      *iconButton;
@property (nonatomic,strong) IBOutlet UILabel       *titleLabel;

@end
