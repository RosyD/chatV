//
//  ACVideoCallViewController.m
//  chat
//
//  Created by Aculearn on 15/1/29.
//  Copyright (c) 2015年 Aculearn. All rights reserved.
//

#import "ACVideoCallViewController.h"
#import "ACNoteListVC_Cell.h"
#import "ACVideoCall.h"
#import "UIImageView+WebCache.h"
#import <AVFoundation/AVAudioPlayer.h>
#import <AVFoundation/AVAudioSession.h>
#import "ACEntity.h"
#import "JHNotificationManager.h"

#if DEBUG
//    #define ACVideoCall_View_Delay_Time 5
#endif

#ifndef ACVideoCall_View_Delay_Time
    #define ACVideoCall_View_Delay_Time  60
#endif

@interface ACVideoCallViewController (){
    ACVideoCallRejectType    _nRejectType;
    AVAudioPlayer*          _pSoundPlayer;
}

@property (weak, nonatomic) IBOutlet UIImageView *userIconImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLable;
@property (weak, nonatomic) IBOutlet UILabel *videoCallTipLable;

@property (weak, nonatomic) IBOutlet UILabel *declineLable;
@property (weak, nonatomic) IBOutlet UILabel *answerLable;
@end

@implementation ACVideoCallViewController

-(instancetype)init{
    self = [super init];
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //关闭提示
    [JHNotificationManager hideNotificationView:NO];
    
    // Do any additional setup after loading the view from its nib.
    _nRejectType    =   REJECTREASON_BUSY; //REJECTREASON_BUSYTIMEOUT;

    [_userIconImageView setToCircle];
//    [_userIconImageView.layer setMasksToBounds:YES];
//    [_userIconImageView.layer setCornerRadius:5.0];
    
    ACVideoCall* pCaller = [ACVideoCall shareVideoCall];
    
    _declineLable.text      =   NSLocalizedString(@"VideoCall_Decline", nil);
    _answerLable.text       =   NSLocalizedString(@"VideoCall_Answer", nil);
    
    if(pCaller.isGroupCall){
        ACTopicEntity* pTopicEntity = pCaller.groupTopicEntity;
        
        _userNameLable.text = pTopicEntity.title;
        
        //组icon
        NSString* pIcon = pTopicEntity.icon;
        
        if (pIcon){
            [_userIconImageView setImageWithIconString:pIcon
                                      placeholderImage:[UIImage imageNamed:@"icon_groupchat.png"]
                                             ImageType:ImageType_TopicEntity];
        }
        else{
            _userIconImageView.image = [UIImage imageNamed:@"icon_groupchat.png"];
        }
    }
    else{
        _userNameLable.text = _caller.name;
        [ACNoteListVC_Cell setUserIcon:_caller forImageView:_userIconImageView];
    }
    
    _videoCallTipLable.text =   pCaller.callTip;
    
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
//    [[UIDevice currentDevice] setProximityMonitoringEnabled:YES];

    
    _pSoundPlayer   =   [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource: @"lineapp_ring_16k" ofType: @"wav"]] error:nil];
    [_pSoundPlayer prepareToPlay];
    [_pSoundPlayer setNumberOfLoops:100];
    [_pSoundPlayer play];
    
    // Animate Out
    [self performSelector:@selector(slideOutFunc)
               withObject:self
               afterDelay:ACVideoCall_View_Delay_Time];
    
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:)
//                                                 name:UIApplicationWillResignActiveNotification object:nil];
    //监听是否触发home键挂起程序.
    //这个放在app中处理，放在这里会被下面拖出的系统控制条打断，用户调整音量什么的就会失败
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_pSoundPlayer stop];
    _pSoundPlayer = nil;
    
    //清除
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//-(void)applicationWillResignActive:(id) tt{
//    [self dismissViewControllerAnimated:NO completion:nil];
//    [[ACVideoCall shareVideoCall] onUserAccept:REJECTREASON_BUSY];
//}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)slideOutFunc{
    [self dismissViewControllerAnimated:YES completion:^{
        [[ACVideoCall shareVideoCall] onUserAccept:_nRejectType];
    }];
}

-(void)cancelWithBlock:(void (^)(void))completion{
    [self dismissViewControllerAnimated:NO completion:completion];
}

#pragma mark -- Active

- (IBAction)onDecline:(id)sender {
    _nRejectType = REJECTREASON_BUSY;
    [self slideOutFunc];    
}


- (IBAction)onAnswer:(id)sender {
    _nRejectType = REJECTREASON_UserAccept;
    [self slideOutFunc];
}


@end
