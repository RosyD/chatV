//
//  ACMapBrowerViewController.m
//  AcuCom
//
//  Created by 王方帅 on 14-4-18.
//  Copyright (c) 2014年 aculearn. All rights reserved.
//

#import "ACMapBrowerViewController.h"
#import "UINavigationController+Additions.h"
#import "ACConfigs.h"
#import "UIView+Additions.h"

@interface ACMapBrowerViewController ()

@end

@implementation ACMapBrowerViewController

- (void)dealloc
{
    _mapView.delegate = nil;
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _mapView.centerCoordinate = _coordinate;
    if (![ACConfigs isPhone5])
    {
        [_mapView setFrame_height:_mapView.size.height-88];
    }
    
    _isFirstBrowser = YES;
    MKPointAnnotation *ann = [[MKPointAnnotation alloc] init];
    ann.coordinate = _coordinate;
    [_mapView addAnnotation:ann];
    [_backButton setTitle:NSLocalizedString(@"Back", nil) forState:UIControlStateNormal];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(hotspotStateChange:) name:kHotspotOpenStateChangeNotification object:nil];
}

-(void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    [self initHotspot];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self initHotspot];
}

#pragma mark -notification
-(void)hotspotStateChange:(NSNotification *)noti
{
    if (_isOpenHotspot)
    {
        [_mapView setFrame_height:_mapView.size.height-hotsoptHeight];
    }
    else
    {
        [_mapView setFrame_height:_mapView.size.height+hotsoptHeight];
    }
}

#pragma mark -mapViewDelegate
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    if (_isFirstBrowser)
    {
        _isFirstBrowser = NO;
        CLLocation *objectLocaton = [[CLLocation alloc] initWithLatitude:_coordinate.latitude longitude:_coordinate.longitude];
        CLLocation *selfLocaton = userLocation.location;
        double distance = [selfLocaton distanceFromLocation:objectLocaton];
        _mapView.region = MKCoordinateRegionMake(_coordinate, MKCoordinateSpanMake(distance/1000000.0, distance/1000000.0));
    }
}

#pragma mark -IBAction
-(IBAction)goback:(id)sender
{
    ITLog(@"TXB");
    [self ACdismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
