//
//  YLImageView.h
//  YLGIFImage
//
//  Created by Yong Li on 14-3-2.
//  Copyright (c) 2014年 Yong Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YLImageView : UIImageView
{
    NSTimer *mpTimer;
}

@property (nonatomic, copy) NSString *runLoopMode;

-(void)pauseAnimating;

-(void)continueAnimating;

@end
