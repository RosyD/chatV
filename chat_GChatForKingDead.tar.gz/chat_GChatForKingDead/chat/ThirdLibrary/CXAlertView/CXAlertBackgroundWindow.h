//
//  CXAlertBackgroundWindow.h
//  CXAlertViewDemo
//
//  Created by ChrisXu on 13/9/12.
//  Copyright (c) 2013年 ChrisXu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CXAlertBackgroundWindow : UIWindow

@end
