//
//  POPDTableView.m
//  popdowntable
//
//  Created by 王方帅 on 14-6-13.
//  Copyright (c) 2014年 Alex Di Mango. All rights reserved.
//

#import "POPDTableView.h"
#import "POPDCell.h"
#import "UIView+Additions.h"

static NSString *kheader = @"menuSectionHeader";
static NSString *ksubSection = @"menuSubSection";

@interface POPDTableView ()
@property NSArray *sections;
@property (strong, nonatomic) NSMutableArray *sectionsArray;
@end

@implementation POPDTableView

- (void)setMenuSections:(NSArray *)menuSections{
    
    self.sections = menuSections;
    self.selectedIndexDic = [NSMutableDictionary dictionaryWithCapacity:3];
    
    self.delegate = self;
    self.dataSource = self;
    
    self.backgroundColor = TABLECOLOR;
    [self setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    self.sectionsArray = [NSMutableArray new];
    self.showingArray = [NSMutableArray new];
    
    for (int i = 0; i < [menuSections count]; i++)
    {
        NSDictionary *sec = [menuSections objectAtIndex:i];
        NSString *header = [sec objectForKey:kheader];
        NSArray *subSection = [sec objectForKey:ksubSection];
        
        NSMutableArray *section = [NSMutableArray new];
        [section addObject:header];
        
        for (NSString *sub in subSection) {
            [section addObject:sub];
        }
        [self.sectionsArray addObject:section];
        if (i == 0)
        {
            [self.showingArray addObject:[NSNumber numberWithBool:YES]];
        }
        else
        {
            [self.showingArray addObject:[NSNumber numberWithBool:NO]];
        }
    }
    
    [self reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.sectionsArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (![[self.showingArray objectAtIndex:section]boolValue]) {
        return 1;
    }
    else{
        return [[self.sectionsArray objectAtIndex:section]count];;
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row ==0){
        if([[self.showingArray objectAtIndex:indexPath.section]boolValue]){
            [cell setBackgroundColor:CELLSELECTED];
        }else{
            [cell setBackgroundColor:[UIColor clearColor]];
        }
    }
    else
    {
        [cell setBackgroundColor:CELLUNSELECTED];
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"menuCell";
#warning : Use here your custom cell, instead of POPDCell
    
    POPDCell *cell = nil;
    cell = (POPDCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"POPDCell" owner:self options:nil];
    
    if (cell == nil) {
        cell = [topLevelObjects objectAtIndex:0];
    }
    
    if (indexPath.row == 0)
    {
        [cell.labelText setFrame_x:9];
        [cell.selectedButton setHidden:YES];
    }
    else
    {
        [cell.labelText setFrame_x:40];
        [cell.selectedButton setHidden:NO];
        if ([_selectedIndexDic objectForKey:indexPath])
        {
            [cell.selectedButton setSelected:[[_selectedIndexDic objectForKey:indexPath] boolValue]];
        }
        else
        {
            [cell.selectedButton setSelected:NO];
        }
    }
    
    cell.labelText.text = [[self.sectionsArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.labelText.textColor = TEXT;
    cell.separator.backgroundColor = SEPARATOR;
    cell.sepShadow.backgroundColor = SEPSHADOW;
    cell.shadow.backgroundColor = SHADOW;
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if([[self.showingArray objectAtIndex:indexPath.section]boolValue]){
//        [self.showingArray setObject:[NSNumber numberWithBool:NO] atIndexedSubscript:indexPath.section];
        POPDCell *cell = (POPDCell *)[tableView cellForRowAtIndexPath:indexPath];
        if (indexPath.row != 0)
        {
            [cell.selectedButton setSelected:!cell.selectedButton.selected];
            if (cell.selectedButton.selected == YES)
            {
                [_selectedIndexDic setObject:[NSNumber numberWithBool:cell.selectedButton.selected] forKey:indexPath];
            }
            else
            {
                [_selectedIndexDic removeObjectForKey:indexPath];
            }
        }
    }else{
        [_selectedIndexDic removeAllObjects];
        
        [self.showingArray setObject:[NSNumber numberWithBool:YES] atIndexedSubscript:indexPath.section];
        NSMutableIndexSet *set = [[NSMutableIndexSet alloc] initWithIndex:indexPath.section];
        for (int i = 0; i < [_showingArray count]; i++)
        {
            if (i != indexPath.section)
            {
                if ([[self.showingArray objectAtIndex:i] boolValue])
                {
                    [self.showingArray setObject:[NSNumber numberWithBool:NO] atIndexedSubscript:i];
                    [set addIndex:i];
                }
            }
        }
        [tableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
    [self.popdDelegate didSelectRowAtIndexPath:indexPath];
}

@end
