//
//  POPDCell.h
//  popdowntable
//
//  Created by Alex Di Mango on 15/09/2013.
//  Copyright (c) 2013 Alex Di Mango. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface POPDCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *labelText;
@property (strong, nonatomic) IBOutlet UILabel *separator;
@property (strong, nonatomic) IBOutlet UILabel *sepShadow;
@property (strong, nonatomic) IBOutlet UILabel *shadow;
@property (strong, nonatomic) IBOutlet UIButton *selectedButton;

@end
