//
//  POPDTableView.h
//  popdowntable
//
//  Created by 王方帅 on 14-6-13.
//  Copyright (c) 2014年 Alex Di Mango. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef MB_STRONG
#if __has_feature(objc_arc)
#define MB_STRONG strong
#else
#define MB_STRONG retain
#endif
#endif

#ifndef MB_WEAK
#if __has_feature(objc_arc_weak)
#define MB_WEAK weak
#elif __has_feature(objc_arc)
#define MB_WEAK unsafe_unretained
#else
#define MB_WEAK assign
#endif
#endif

#define TABLECOLOR [UIColor colorWithRed:230.0/255.0 green:230.0/255.0 blue:230.0/255.0 alpha:0.5]
#define CELLUNSELECTED [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:0.5]
#define CELLSELECTED [UIColor colorWithRed:151.0/255.0 green:206.0/255.0 blue:232.0/255.0 alpha:0.3]
#define SEPARATOR [UIColor colorWithRed:130.0/255.0 green:130.0/255.0 blue:130.0/255.0 alpha:0.5]
#define SEPSHADOW SEPARATOR
#define SHADOW SEPSHADOW
#define TEXT [UIColor colorWithRed:38.0/255.0 green:38.0/255.0 blue:38.0/255.0 alpha:1.0]

@protocol POPDDelegate <NSObject>

-(void) didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface POPDTableView : UITableView<UITableViewDataSource,UITableViewDelegate>

@property (MB_WEAK) id<POPDDelegate> popdDelegate;
@property (nonatomic,strong) NSMutableDictionary    *selectedIndexDic;
@property (strong, nonatomic) NSMutableArray        *showingArray;

- (void)setMenuSections:(NSArray *)menuSections;

@end
