//
//  AcuDeviceHardware.h
//  AcuConference
//
//  Created by Aculearn on 10/31/13.
//  Copyright (c) 2013 aculearn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AcuDeviceHardware : NSObject

+ (NSString *) platformString;

@end
