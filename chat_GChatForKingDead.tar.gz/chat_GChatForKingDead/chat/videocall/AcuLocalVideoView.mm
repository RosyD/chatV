//
//  AcuLocalVideoView.m
//  AcuConference
//
//  Created by aculearn on 13-7-12.
//  Copyright (c) 2013年 aculearn. All rights reserved.
//

#import "AcuLocalVideoView.h"

@implementation AcuLocalVideoView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
