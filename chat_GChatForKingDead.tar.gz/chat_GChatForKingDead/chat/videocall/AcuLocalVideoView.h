//
//  AcuLocalVideoView.h
//  AcuConference
//
//  Created by aculearn on 13-7-12.
//  Copyright (c) 2013年 aculearn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AcuLocalVideoView : UIView

@end
