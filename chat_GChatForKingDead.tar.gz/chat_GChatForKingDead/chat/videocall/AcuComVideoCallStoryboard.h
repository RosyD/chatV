//
//  AcuComBundleStoryboard.h
//  videocall
//
//  Created by Aculearn on 15-1-20.
//  Copyright (c) 2015年 Aculearn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AcuComVideoCallStoryboard : NSObject

+ (id)acuComVideoCallStoryboardNamed:(NSString*)name;

@end
