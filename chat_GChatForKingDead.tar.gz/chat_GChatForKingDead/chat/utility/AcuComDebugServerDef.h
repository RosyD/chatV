//用于描述AcuComDebug信息
//#define acuCom_Debug_Login_Server @"https://accounts.chat.advanceddigital.co.th"