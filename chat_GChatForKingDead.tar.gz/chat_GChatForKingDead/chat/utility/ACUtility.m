//
//  ACUtility.m
//  chat
//
//  Created by Aculearn on 14/12/31.
//  Copyright (c) 2014年 Aculearn. All rights reserved.
//

#import "ACUtility.h"
#import <AVFoundation/AVFoundation.h>


void AC_ShowTipFunc(NSString*pTitle,NSString* pTip){
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:pTitle message:pTip delegate:nil cancelButtonTitle:NSLocalizedString(@"OK", nil) otherButtonTitles:nil, nil];
    [alert show];
}

@implementation ACUtility

+(void)ShowTip:(NSString*)pTip withTitle:(NSString*)pTitle{
    AC_ShowTipFunc(pTitle,pTip);
}

+(NSString*)getOEMStringFromAbout:(NSString*)pKey{
    NSString* pRet = NSLocalizedStringFromTable(pKey,@"about",nil);
    if([pRet isEqualToString:pKey]){
        pRet = NSLocalizedString(pKey,nil);
    }
    return pRet;
}

+(int)getValueWithName:(NSString*)pName fromDict:(NSDictionary *)dicPerm andDefault:(int)nDefault{
    id object = [dicPerm objectForKey:pName];
    return object?([object intValue]):nDefault;
}

+(CGFloat)getVideoDuration:(NSURL*) URL
{
    NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO]
                                                     forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
    AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:URL options:opts];
    float second = 0;
    second = urlAsset.duration.value/urlAsset.duration.timescale;
    return second;
}

+(NSDate*)nowLocalDate{ //取得当前本地日期
    NSDate *date = [NSDate date]; //取得的时GTM时间
    
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: date];
    
    return [date  dateByAddingTimeInterval: interval]; //返回当前时区的时间
    
}

+(int)scrollViewScrollStat:(UIScrollView*) pScrollView{ //返回ScrollView_ScrollStat_*
    //main_tableView 滚动状态
    CGRect bounds = pScrollView.bounds;
    CGSize size = pScrollView.contentSize;
    
    if(size.height<=bounds.size.height){
        //显示了全部
//        ITLogEX(@"显示全部");
        return ScrollView_ScrollStat_Showed_All;
    }
    
    CGPoint offset = pScrollView.contentOffset;
    if(offset.y<5){
//        NSLog(@"到头");

        return  ScrollView_ScrollStat_Showed_Head;
    }
    
    if(offset.y+bounds.size.height>=(size.height-10)){
//        NSLog(@"到尾");

        return ScrollView_ScrollStat_Showed_Tail;
    }
//    ITLogEX(@"%f,%f 中间",offset.y+bounds.size.height,size.height);
    return  ScrollView_ScrollStat_Showed_Center;
}

//{
//    UILocalNotification *notification = [[UILocalNotification alloc] init];
//    notification.alertBody = content;
//    notification.alertAction = action;
//    notification.soundName = UILocalNotificationDefaultSoundName;
//    [[UIApplication sharedApplication] presentLocalNotificationNow:notification];
//
//}
+(BOOL)checkVideo:(NSURL*)URL Deuration:(CGFloat)dure{
    if([ACUtility getVideoDuration:URL]>dure){
        //提示错误
        [ACUtility ShowTip:[NSString stringWithFormat:NSLocalizedString(@"Video_Time_Toooooo_Format", nil),(int)dure] withTitle:nil];
        return YES;
    }
    return NO;
}

+(long)getFileSizeWithPath:(NSString *)path{
    NSError *error = nil;
    NSDictionary *dic = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:&error];
    if (error){
        return 0;
    }
    return [dic fileSize];
}

+(UIImage*)thumbFromMovieURL:(NSURL*)pURL{
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:pURL options:nil];
    AVAssetImageGenerator *gen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    gen.appliesPreferredTrackTransform = YES;
    CMTime time = CMTimeMakeWithSeconds(1.0, 600);
    NSError *error = nil;
    CMTime actualTime;
    CGImageRef image = [gen copyCGImageAtTime:time actualTime:&actualTime error:&error];
    UIImage *thumb = [[UIImage alloc] initWithCGImage:image];
    CGImageRelease(image);
    return thumb;
    
/*
 需要添加AVFoundation和CoreMedia.framework
 另外一种那个方法
 
 
 MPMoviePlayerController *moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:videoURL]; moviePlayer.shouldAutoplay = NO;
 UIImage *thumbnail = [moviePlayer thumbnailImageAtTime:time timeOption:MPMovieTimeOptionNearestKeyFrame];
 //这个也一样
 
 +(UIImage *)fFirstVideoFrame:(NSString *)path
 {
 MPMoviePlayerController *mp = [[MPMoviePlayerController alloc]
 initWithContentURL:[NSURL fileURLWithPath:path]];
 UIImage *img = [mp thumbnailImageAtTime:0.0
 timeOption:MPMovieTimeOptionNearestKeyFrame];
 [mp stop];
 [mp release];
 return img;
 }
 */
    
}

#define ACUtility_LogFilePath   [NSTemporaryDirectory() stringByAppendingPathComponent:@"AcuCom.log"]

+(void)LogFile_Swich{
    NSString *logPath   =   ACUtility_LogFilePath;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
//    printf("%s\n",logPath.UTF8String);

    if ([fileManager fileExistsAtPath:logPath]&&
        [[fileManager attributesOfItemAtPath:logPath error:nil] fileSize]>5*1024*1024){
        [fileManager removeItemAtPath:logPath error:nil];
    }
    
    freopen([logPath cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
}


+(NSData*)LogFile_Load:(BOOL)bClear{
    NSString *logPath   =   ACUtility_LogFilePath;
    fclose(stderr);
    NSData* pRet = [NSData dataWithContentsOfFile:logPath];
    if(bClear){
        [[NSFileManager defaultManager] removeItemAtPath:logPath error:nil];
    }
    freopen([logPath cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
    return pRet;
}

#ifdef ACUtility_Log_UseStringBuffers
//使用日志缓冲区
NSMutableString*    g___Log_UseStringBuffers = nil;
+(void)  ITLogUserStringBuffers_Add:(NSString*) pStr{
    if(nil==g___Log_UseStringBuffers){
        g___Log_UseStringBuffers = [[NSMutableString alloc] initWithCapacity:1024*1024];
    }
    [g___Log_UseStringBuffers appendFormat:@"%@\n",pStr];
}
void        ITLogUserStringBuffers_Clear(){
    [g___Log_UseStringBuffers setString:@""];
}
NSString*   ITLogUserStringBuffers_Strings(){
    return g___Log_UseStringBuffers;
}
#endif

static int _loadFileIconFunc(const char* pExt,const char** pExts){
    int nRet = 0;
    while(*pExts){
        if(0==strcmp(pExt, *pExts)){
            return nRet;
        }
        pExts ++;
        nRet ++;
    }
    return -1;
}

+(UIImage*) loadFileIcon:(NSString*)fileName{
    return [self loadFileExtIcon:fileName.pathExtension];
}

+(UIImage*) loadFileExtIcon:(NSString*)ext{
    static const char* media_ext[]={"asf","avi","wm","wmp","wmv","ram","rm","rmvb","rp","rpm","rt","smi","smil","m1v","m2v","m2p","m2t","m2ts","mp2v","mpe","mpeg","mpg","mpv2","pss","pva","tp","tpr","ts","m4b","m4p","m4v","mp4","mpeg4","3g2","3gp","3gp2","3gpp","mov","qt","f4v","flv","hlv","swf","ifo","vob","amv","bik",
"csf","divx","evo","ivm","mkv","mod","mts","ogm","pmp","scm","tod","vp6","webm","xlmv","aac","ac3","amr","ape","cda","dts","flac","m1a","m2a","m4a","mid","midi","mka","mp2","mp3","mpa","ogg","ra","tak","tta","wav","wma","wv","asx","cue","kpl","m3u","pls","qpl","smpl","ass","srt","ssa","dat",NULL};
    static const char*  office_ext[] = {"doc","docx","docm","dotx","dotm",NULL};
    static const char*  ppts_ext[] = {"ppt","pptx","pptm","ppsx","ppsm","potx","potm","ppam",NULL};
    static const char*  excels_ext[] = {"xls","xlsx","xlsm","xltx","xltm","xlsb","xlam",NULL};
    static const char*  zip_ext[] = {"rar","zip","tar","gz",NULL};
    static const char*  img_ext[]={"jpg","gif","png","jpg","jpeg","tif","bmp",NULL};
    
    NSString* pRetIconName = @"file_icon_normal";
    ext = ext.lowercaseString;
    if(ext.length>0){
        const char* pFileEx = ext.UTF8String;
        if(_loadFileIconFunc(pFileEx,media_ext)>=0){
            pRetIconName = @"file_icon_media";
        }
        else if(_loadFileIconFunc(pFileEx,office_ext)>=0){
            pRetIconName = @"file_icon_doc";
        }
        else if(_loadFileIconFunc(pFileEx,ppts_ext)>=0){
            pRetIconName = @"file_icon_ppt";
        }
        else if(_loadFileIconFunc(pFileEx,excels_ext)>=0){
            pRetIconName = @"file_icon_xls";
        }
        else if(_loadFileIconFunc(pFileEx,zip_ext)>=0){
            pRetIconName = @"file_icon_rar";
        }
        else if(_loadFileIconFunc(pFileEx,img_ext)>=0){
            pRetIconName = @"file_icon_pic";
        }
        else{
            static const char*  other_ext[]= {"html","htm","chm","txt","pdf","vcf",NULL};

            int nOther = _loadFileIconFunc(pFileEx,other_ext);
            if(nOther>=0){
                if(nOther<2){ //0,1
                    pRetIconName = @"file_icon_html";
                }
                else if(2==nOther){
                    pRetIconName = @"file_icon_chm";
                }
                else if(3==nOther){
                    pRetIconName = @"file_icon_plaintext";
                }
                else if(4==nOther){
                    pRetIconName = @"file_icon_pdf";
                }
                else if(5==nOther){
                    pRetIconName = @"file_icon_vcf";
                }
            }
        }
    }
    
//    file_icon_download
//    file_icon_onenote
    return [UIImage imageNamed:pRetIconName];
}

/*
 public static void setImageViewByFileExtension (ImageView iv, String extension) {
 String[] mediaExtensions = new String[] {"asf","avi","wm","wmp","wmv","ram","rm","rmvb","rp","rpm","rt","smi","smil","m1v","m2v","m2p","m2t","m2ts","mp2v","mpe","mpeg","mpg","mpv2","pss","pva","tp","tpr","ts","m4b","m4p","m4v","mp4","mpeg4","3g2","3gp","3gp2","3gpp","mov","qt","f4v","flv","hlv","swf","ifo","vob","amv","bik",
 "csf","divx","evo","ivm","mkv","mod","mts","ogm","pmp","scm","tod","vp6","webm","xlmv","aac","ac3","amr","ape","cda","dts","flac","m1a","m2a","m4a","mid","midi","mka","mp2","mp3","mpa","ogg","ra","tak","tta","wav","wma","wv","asx","cue","kpl","m3u","pls","qpl","smpl","ass","srt","ssa","dat"};
 
 List<String> mediaExLists = Arrays.asList(mediaExtensions);
 String[] words = new String[] {"doc","docx","docm","dotx","dotm"};
 List<String> wordList = Arrays.asList(words);
 String[] ppts = new String[] {"ppt","pptx","pptm","ppsx","ppsm","potx","potm","ppam"};
 List<String> pptList = Arrays.asList(ppts);
 String[] excels = new String[] {"xls","xlsx","xlsm","xltx","xltm","xlsb","xlam"};
 List<String> excelList = Arrays.asList(excels);
 
 if (extension.equalsIgnoreCase("html") || extension.equalsIgnoreCase("htm")) {
 iv.setImageResource(R.drawable.file_icon_html);
 } else if (extension.equalsIgnoreCase("chm")) {
 iv.setImageResource(R.drawable.file_icon_chm);
 } else if (wordList.contains(extension)) {
 iv.setImageResource(R.drawable.file_icon_doc);
 } else if (excelList.contains(extension)) {
 iv.setImageResource(R.drawable.file_icon_xls);
 } else if (pptList.contains(extension)) {
 iv.setImageResource(R.drawable.file_icon_ppt);
 } else if (extension.equalsIgnoreCase("rar") || extension.equalsIgnoreCase("zip") || extension.equalsIgnoreCase("tar") || extension.equalsIgnoreCase("gz")) {
 iv.setImageResource(R.drawable.file_icon_rar);
 } else if (extension.equalsIgnoreCase("txt")) {
 iv.setImageResource(R.drawable.file_icon_plaintext);
 } else if (extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("gif") || extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("tif") || extension.equalsIgnoreCase("bmp")) {
 iv.setImageResource(R.drawable.file_icon_pic);
 } else if (mediaExLists.contains(extension)) {
 iv.setImageResource(R.drawable.file_icon_media);
 } else if (extension.equalsIgnoreCase("pdf")) {
 iv.setImageResource(R.drawable.file_icon_pdf);
 } else if(extension.equals("vcf")) {
 iv.setImageResource(R.drawable.file_icon_vcf);
 } else {
 iv.setImageResource(R.drawable.file_icon_normal);
 }
 }
 */


@end



#ifdef Enum_2_Str_ITEM_DEF

const char* Enum_2_Str_FindItemFunc(int nEnum_Value,struct Enum_2_Str_ITEM* pEnum2StrItemsHead){
    while(pEnum2StrItemsHead->pTypeName){
        if(pEnum2StrItemsHead->enum_value==nEnum_Value){
            return pEnum2StrItemsHead->pTypeName;
        }
        pEnum2StrItemsHead ++;
    }
    return "...............................出现错误啦........................";
}
#endif
